import javax.swing.*;
import java.awt.*;
public class JButtonDemo {
    
    public static void main(String[] args) {
    //  how to create setFont(),setText(),setForeground(); setBackground(); setCursor();setEnabled(); setVisible() how to use image in jButton
     JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100, 100, 1000, 500);
        Container c = frame.getContentPane();
        c.setLayout(null); 
    // create the button

        JButton btn = new JButton("Click Me");
        btn.setSize(120,30);
        btn.setLocation(100,100);
        c.add(btn);
 
    // font and text change 
    Font font=new Font("Arial",Font.BOLD,20);

    btn.setFont(font);
    btn.setText("pressIt");

    // change the background and text color
    btn.setForeground(Color.RED);
    btn.setBackground(Color.YELLOW);

    // for change the cursor style for this we need to make the cursor class obj

    Cursor cur = new Cursor(Cursor.HAND_CURSOR);// styling like HAND_CURSOR,WAIT_CURSOR,CROSSHAIR_CURSOR
    btn.setCursor(cur);

    // FOR ENABLE AND DISABLE THE BUTTON
    btn.setEnabled(true);// for true it is showing but for false we can't click on the button
    btn.setVisible(true);//this seesthe button existence 
  

// for showing the image in the button :) for this we need to make the obj of Imageicon and pass the refernece in the JButton
ImageIcon icon = new ImageIcon(
    "C:\\Users\\palak.agarwal1\\Downloads\\swing-main\\swing-main\\Swingprogram\\garden-flower-close-up-35646.jpg"
);

Image img = icon.getImage();
Image scaledImg = img.getScaledInstance(120, 120, Image.SCALE_SMOOTH);

ImageIcon scaledIcon = new ImageIcon(scaledImg);

JButton btn1 = new JButton(scaledIcon);
btn1.setBounds(100, 100, 120, 120);

c.add(btn1);


    frame.setVisible(true);
        
    }
}
