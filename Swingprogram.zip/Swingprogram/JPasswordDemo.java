import javax.swing.*;
import java.awt.*;
public class JPasswordDemo {
    public static void main(String[] args) {
        // text and password filed are almost same 
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,1000,500);
        Container c = frame.getContentPane();
        c.setLayout(null);
         
        // JPassword
         JPasswordField pass = new JPasswordField();
         pass.setBounds(100,50,120,30);
         c.add(pass);

        // for manually set the text
        pass.setText("12345678");
        pass.setFont(new Font("Arial",Font.BOLD,10));

        // we want to showcase the # rather than .
        pass.setEchoChar('%');
        // for showing the password;
        pass.setEchoChar((char)0);
         

        frame.setVisible(true);

    }
    
}
