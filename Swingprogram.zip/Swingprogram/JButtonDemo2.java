import java.awt.*;
import javax.swing.*;
public class JButtonDemo2 {
    public static void main(String[] args) {
        
        JFrame frame = new JFrame(); // Creating main window (frame)
        frame.setBounds(100, 100, 1000, 500); // Setting position & size of frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close app when window is closed

        Container c = frame.getContentPane(); // Getting the content area of the frame
        c.setLayout(null); // Disabling default layout to use manual positions

        frame.setVisible(true);
        
        
    }
    
}
