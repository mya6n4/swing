// import java.awt.*;                     // Used for Font, Container, etc.
// import javax.swing.*;                  // Used for JFrame, JLabel, etc.

// public class JLabelDemo {              // Class name should start with Capital letter

//     public static void main(String args[]) {

//         JFrame frame = new JFrame();   // Creating main window (frame)
//         frame.setBounds(100, 100, 1000, 500); // Setting position & size of frame
//         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close app on exit

//         Container c = frame.getContentPane(); // Getting container of frame
//         c.setLayout(null);             // Removing default layout to use manual positioning

//         // // JLabel label = new JLabel();   // Creating empty JLabel
//         // label.setBounds(100, 50, 200, 30); // Setting position & size of JLabel

//         // label.setText("Password");    // Setting text inside JLabel

//         // Font font = new Font("Arial", Font.PLAIN, 30); // Creating Font object
//         // label.setFont(font);          // Applying font to JLabel

//          // ✅ Load image
//         // ImageIcon icon = new ImageIcon(
//         //     "C:\\Users\\Dell\\OneDrive\\Desktop\\swing\\Swingprogram\\khadeeja-yasser-3U9L9Chc3is-unsplash.jpg"
//         // );

//         // // ✅ Create JLabel with BOTH text + image
//         // JLabel label = new JLabel("Text", icon, JLabel.CENTER);

//         // // ✅ Set position & size
//         // label.setBounds(0, 0, 1000, 500);

//         // // ✅ Add to container FIRST
//         // c.add(label);

//         // // ✅ Then make frame visible
//         // frame.setVisible(true);  
//          ImageIcon icon = new ImageIcon(
//             "C:\\Users\\palak.agarwal1\\Downloads\\swing-main\\swing-main\\Swingprogram\\garden-flower-close-up-35646.jpg"
//         );

//         // ✅ Set FIXED image size (you can change 400x300)
//         Image img = icon.getImage();
//         Image scaledImg = img.getScaledInstance(400, 300, Image.SCALE_SMOOTH);
//         ImageIcon fixedIcon = new ImageIcon(scaledImg);

//         // ✅ Create JLabel with fixed-size image
//         JLabel label = new JLabel("Starbucks", fixedIcon, JLabel.CENTER);

// // ✅ Text on top of image
// label.setHorizontalTextPosition(JLabel.CENTER);
// label.setVerticalTextPosition(JLabel.CENTER);

// // ✅ Text styling
// label.setForeground(Color.WHITE);
// label.setFont(new Font("Arial", Font.BOLD, 28));

//         // ✅ CENTER the image manually
//         int x = (1000 - 400) / 2;   // frame width - image width
//         int y = (500 - 300) / 2;    // frame height - image height
//         label.setBounds(x, y, 400, 300);

//         c.add(label);
//         frame.setVisible(true);
//     }
// }

import javax.swing.*;
import java.awt.*;

public class JLabelDemo {
    public static void main(String args[]) {

        JFrame frame = new JFrame(); // Creating main window (frame)
        frame.setBounds(100, 100, 1000, 500); // Setting position & size of frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close app when window is closed

        Container c = frame.getContentPane(); // Getting the content area of the frame
        c.setLayout(null); // Disabling default layout to use manual positions

        // JLabel label = new JLabel("Username"); // Creating JLabel
        // label.setBounds(100, 50, 200, 30); // Set x, y, width, height

        // label.setText("Password"); // change the text dynamically

        // Font font = new Font("Arial", Font.ITALIC, 30);// change the font of the text
        // label.setFont(font);

        // c.add(label); // Adding label to container
        ImageIcon icon = new ImageIcon(
                "C:\\Users\\palak.agarwal1\\Downloads\\swing-main\\swing-main\\Swingprogram\\garden-flower-close-up-35646.jpg");

        // Resize image
        Image img = icon.getImage();
        Image scaledImg = img.getScaledInstance(400, 300, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImg);

        // Label with text + image
        JLabel label = new JLabel("palak", scaledIcon, JLabel.CENTER);
        label.setBounds(50, 50, 400, 330);

        // ⭐ Position text relative to image
        label.setHorizontalTextPosition(JLabel.CENTER); // Text alignment
        label.setVerticalTextPosition(JLabel.BOTTOM); // Text below image

        // ⭐ Make text clearly visible
        label.setForeground(Color.BLACK); // <-- IMPORTANT
        label.setFont(new Font("Arial", Font.BOLD, 18)); // Bigger, bold text

        c.add(label);

        frame.setVisible(true); // ✔ always the last step
    }
}