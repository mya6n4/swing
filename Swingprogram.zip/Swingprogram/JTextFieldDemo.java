import javax.swing.*;
import java.awt.*;

public class JTextFieldDemo {
    public static void main(String[] args) {

        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100, 100, 1000, 500);
        Container c = frame.getContentPane();
        c.setLayout(null);

        JTextField t1 = new JTextField();
        t1.setBounds(100, 50, 120, 30);
        c.add(t1);
        // to change the text dynamically
        t1.setText("Palak Agarwal");
        // font change ke liye
        Font font = new Font("Arial", Font.BOLD, 30);
        t1.setFont(font);

        // for forground color chage
        t1.setForeground(Color.red);
        t1.setBackground(Color.yellow);

        // user can adit or not
        t1.setEditable(true);// write the true we can change the text otherwise we can't change the text

        frame.setVisible(true);

    }

}
